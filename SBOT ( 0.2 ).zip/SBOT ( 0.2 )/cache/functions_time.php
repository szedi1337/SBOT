<?php


$funkcje = @scandir('include/files/functions');
	
	$functions = array_diff($funkcje, array('.', '..'));
	foreach($functions as $file)
	{
		$function = str_replace('.php','',$file);
		$time[$function] = date('Y-m-d G:i:s');
	}
	
?> 
