<?php ?><?php
define('VERSION', '1.0.0');
define('AUTHOR', 'SZEDI');
define('CONTACT', 'aspeak.eu');
date_default_timezone_set('Europe/Warsaw');
ini_set('default_charset', 'UTF-8');
setlocale(LC_ALL, 'UTF-8');
include_once 'classes/ts3admin.class.php';
include_once 'include/config/config.php';
include_once 'include/sbot.class.php';
include_once 'cache/functions_time.php';
foreach (array_diff(@scandir('include/files/functions'), array('.', '..')) as $file) {
    include_once ('include/files/functions/' . $file . '');
}
foreach (array_diff(@scandir('include/files/commands'), array('.', '..')) as $file) {
    include_once ('include/files/commands/' . $file . '');
}
system('clear');
$query = new ts3admin($config['connection']['host'], $config['connection']['query_port']);
$options = getopt("i:");
$instanceid = $options['i'];
$instance = new sbot();
echo '[>>] Startowanie SBOT @' . VERSION . ' (Bot stworzony przez: ' . AUTHOR . ')' . PHP_EOL;
echo '[>>] Sprawdzanie licencji...' . PHP_EOL;
if ($instance->checkLicense()) {
    echo '[>>] Licencja poprawna' . PHP_EOL;
} else {
    echo '[>>] Nie odnaleziono licencji' . PHP_EOL;
    echo '[>>] Zatrzymywanie bota...' . PHP_EOL;
    exit();
}
if ($query->getElement('success', $query->connect())) {
    echo '[>>] Startowanie instacji ' . $config[$instanceid]['instance']['name'] . '' . PHP_EOL;
    echo '[>>] Pomyslnie polaczono z serwerem' . PHP_EOL;
    if ($query->getElement('success', $query->login($config['connection']['login'], $config['connection']['password']))) {
        echo '[>>] Pomyslnie zalogowano do serwera' . PHP_EOL;
    } else {
        echo '[>>] Nie udalo zalogowac sie do serwera. Sprawd&#378; plik konfiguracyjny' . PHP_EOL;
    }
    $query->selectServer($config['connection']['port']);
    $query->setName('NAZWA ' . $config[$options['i']]['instance']['name']);
    $tsAdminSocket = $query->runtime['socket'];
    while (1) {
        //$datapetli = date('Y-m-d G:i:s');
        $core = $query->getElement('data', $query->whoAmI());
        $query->clientMove($core['client_id'], $config[$options['i']]['instance']['default_channel']);
        if ($config[$instanceid]['instance']['enable_functions_system']) {
            $funkcje = @scandir('include/files/functions');
            $functions = array_diff($funkcje, array('.', '..'));
            foreach ($functions as $file) {
                $function = str_replace('.php', '', $file);
                if (array_key_exists($function, $config[$instanceid]['functions'])) {
                    if ($config[$instanceid]['functions'][$function]['enabled']) {
                        if (array_key_exists('interval', $config[$instanceid]['functions'][$function])) {
                            if ($instance->can_do($function, $time[$function], $instance->convertinterval($config[$instanceid]['functions'][$function]['interval']))) {
                                echo $function::start();
                                $time[$function] = date('Y-m-d G:i:s');
                            }
                        } else {
                            echo $function::start();
                        }
                    }
                }
            }
        }
        if ($config[$instanceid]['instance']['enable_commands_system']) {
            $instance->sendCommand("servernotifyregister event=textprivate");
            $socketdata = $instance->getData();
            $command = explode(" ", $socketdata['msg']);
            $user = $socketdata['invokerid'];
            $client_info = $query->getElement('data', $query->clientInfo($user));
            $groups = explode(",", $client_info['client_servergroups']);
            $komendy = @scandir('include/files/commands');
            $commands = array_diff($komendy, array('.', '..'));
            foreach ($commands as $file) {
                $komenda = str_replace('.php', '', $file);
                $usage = explode(" ", $config[$instanceid]['commands'][$komenda]['usage']);
                if ($command[0] == $usage[0]) {
                    for ($j = 0;$j < count($config[$instanceid]['commands'][$komenda]['allowedGroups']);$j++) {
                        if ($instance->isInGroup($groups, $config[$instanceid]['commands'][$komenda]['allowedGroups'])) {
                            echo '[>>] Uzytkownik ' . $client_info['client_nickname'] . ' (clid: ' . $user . ') wywolal komende: ' . $command[0] . '' . PHP_EOL;
                            $komenda::start();
                            break;
                        } else {
                            $query->sendMessage(1, $user, 'Nie masz odpowiednich uprawnien do wykonania tej komendy!');
                            break;
                        }
                    }
                }
            }
        }
        clearstatcache();
        sleep($config[$instanceid]['instance']['idle_time']);
    }
} else {
    echo '[>>] Nie udalo polaczyc sie z serwerem. Sprawdz plik konfiguracyjny' . PHP_EOL;
}
?>