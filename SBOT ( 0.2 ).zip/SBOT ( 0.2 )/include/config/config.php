<?php
$config = array();

$config['connection'] = array(

	'host' => '127.0.0.1', //IP serwera
	'port' => '9987', //Port serwera
	'query_port' => '10011', //Port query serwera
	'login' => 'serveradmin', //Nazwa użytkownika query
	'password' => 'XXXX' //Haslo query

);

$config[1]['instance'] = array(
	
	'name' => '@Aktualizator', //Nazwa instancji
	'default_channel' => 2, //Kanał, na którym bot ma siedzieć
	'idle_time' => 1, //Czas ile bot ma odczkekac po wykonaniu wszystkich funkcji
	'enable_functions_system' => true, //Włączyć czy wyłączyć system funkcji
	'enable_commands_system' => true, //Włączyć czy wylaczyc system komend
	'enable_database' => true //Wlaczyc czy wylaczyc baze danych
);

$config[1]['database'] = array(
	
	'host' => '127.0.0.1',
	'user' => 'XXX',
	'password' => 'XXXX',
	'databaseName' => 'SBOT'
	
);

$config[1]['functions'] = array(

	//Jezeli w funkcji nie ma interwału do ustawienia, oznacza to, ze funkcja bedzie wykonywana od razu

	//Funkcja multiFunction wypisuje dane serwerowe w nazwach i opisach kanałów
	'multiFunction' => array(
		'enabled' => true, //Wlaczyc czy wylaczyc funkcje
		'onlineUsers' => array(
			'channelName' => '• Online: [online]', //Nazwa kanalu, na ktorym bedzie wpisywac ilosc osob online
			'cid' => 145 //ID kanału, na ktorym bedzie wpisywac ilosc osob online
		),
		'hour' => array(
			'channelName' => '• Godzina: [hour]', //Nazwa kanalu, na ktorym bedzie wpisywac godzine
			'cid' => 146 //ID kanalu, na ktorym bedzie wpisywac godzine
		),
		'channels' => array(
			'channelName' => '• Ilość kanałow: [channels]', //Nazwa kanalu, na ktorym bedzie wpisywac ilosc kanalow
			'cid' => 147 //ID kanalu, na ktorym bedzie wpisywac ilosc kanalow
		),
		'onlineRecord' => array(
			'channelName' => '• Rekord online: [record]', //Nazwa kanalu, na ktorym bedzie wpisywac rekord online
			'cid' => 83 //ID kanalu, na ktorym bedzie wpisywac rekord online
		),
		'privateChannels' => array(
			'channelName' => '┗→ Ilość kanałów prywatnych: [privateChannels]',
			'cid' => 148,
			'pid' => 116
		),
		'freeChannels' => array(
			'channelName' => '┗→ Ilość wolnych kanałów prywatnych: [freeChannels]',
			'cid' => 149,
			'pid' => 116
		)
	),
	
	//Funkcja autoPoke informuje administrację o pobycie użytkownika na kanale
	'autoPoke' => array(
		'enabled' => true, //Wlaczyc czy wylaczyc funkcje
		'adminsGroups' => array(11,13,14,15,16,17), //Wszystkie grupy administracyjne
		'poke_settings' => array( 
			50 => array(11,13,14,15,16,17), //ID kanalu => grupy administracyjne, ktore ma poekowac po wejsciu na kanal
		),
		'interval' => array('days' => 0,'hours' => 0,'minutes' => 0,'seconds' => 60) //Co jaki czas poekowac adminow
	),
	
	//Funkcja adminList generuje listę administracji
	'adminList' => array(
		'enabled' => true, //Wlaczyc czy wylaczyc funkcje
		'adminsGroups' => array(11,13,14,15,16,17),
		'channel' => 150,
		'interval' => array('days' => 0,'hours' => 0,'minutes' => 0,'seconds' => 5) //Co jaki czas edytowac liste administracji
	),
	
	//Funkcja afkChecker przenosi nieaktywnych użytkownikó na ustalony kanał oraz nadaje ustaloną rangę po spędzeniu określonego czasu bezczynności
	'afkChecker' => array(
		'enabled' => false, //Wlaczyc czy wylaczyc funkcje
		'afkTime' => 10, //Jaki czas trzeba byc idle (czas w minutach)
		'afkGroup' => 28, //ID grupy afk
		'afkChannel' => 170, //ID kanalu afk
		'moveToAFKchannel' => false, //Przenosic na kanal afk?
		'addAFKgroup' => true, //Nadawac range afk?
		'ignoredGroups' => array(10,2,42,44,15,17,18) //ignorowane grupy
	),
	
	//Funkcja channelGroup nadaje ustloną rangę po wejsciu na odpowiedni kanał
	'channelGroup' => array(
		'enabled' => false, //Wlaczyc czy wylaczyc funkcje
		'channels' => array(
			71 => 55, //id kanału => id grupy
			72 => 56 //id kanału => id grupy
		),
		'allGroups' => array(71,72) //Wszystkie grupy rejestracyjne
	),
	
	//Funkcja getChannel tworzy użytkownikowi kanał prywatny po wejsciu na odpowiedni kanał
	'getChannel' => array(
		'enabled' => true, //Wlaczyc czy wylaczyc funkcje
		'cid' => 57, //ID kanalu, na ktorym, po wejsciu bedzie nadawac kanal prywtny
		'groups' => array(71,72), //Grupy wymagane do otrzymania kanalu prywatnego
		'channelGroup' => 16, //ID głownej rangi kanałowej
		'subChannels' => 5 //Ile podkanalow ma tworzyc
	),
	
	//Funkcja hostMessage edytuje wiadmość hosta serwera i wpisuje w nią informajce o serwerze
	'hostMessage' => array(
		'enabled' => true, //Wlaczyc czy wylaczyc funkcje
		'interval' => array('days' => 0,'hours' => 0,'minutes' => 0,'seconds' => 5) //Co jaki czas ma edytowac host message serwera
	),
	
	//Funkcja nickProtection sprawdza czy użytkownik posiada nazwę zgodną z regulaminem
	'nickProtection' => array(
		'enabled' => true, //Wlaczyc czy wylaczyc funkcje
		'protectedWords' => array('chuj','chuja', 'chujek', 'chuju', 'chujem', 'chujnia',
'chujowy', 'chujowa', 'chujowe', 'cipa', 'cipę', 'cipe', 'cipą',
'cipie', 'dojebać','dojebac', 'dojebie', 'dojebał', 'dojebal',
'dojebała', 'dojebala', 'dojebałem', 'dojebalem', 'dojebałam',
'dojebalam', 'dojebię', 'dojebie', 'dopieprzać', 'dopieprzac',
'dopierdalać', 'dopierdalac', 'dopierdala', 'dopierdalał',
'dopierdalal', 'dopierdalała', 'dopierdalala', 'dopierdoli',
'dopierdolił', 'dopierdolil', 'dopierdolę', 'dopierdole', 'dopierdoli',
'dopierdalający', 'dopierdalajacy', 'dopierdolić', 'dopierdolic',
'dupa', 'dupie', 'dupą', 'dupcia', 'dupeczka', 'dupy', 'dupe', 'huj',
'hujek', 'hujnia', 'huja', 'huje', 'hujem', 'huju', 'jebać', 'jebac',
'jebał', 'jebal', 'jebie', 'jebią', 'jebia', 'jebak', 'jebaka', 'jebal',
'jebał', 'jebany', 'jebane', 'jebanka', 'jebanko', 'jebankiem',
'jebanymi', 'jebana', 'jebanym', 'jebanej', 'jebaną', 'jebana',
'jebani', 'jebanych', 'jebanymi', 'jebcie', 'jebiący', 'jebiacy',
'jebiąca', 'jebiaca', 'jebiącego', 'jebiacego', 'jebiącej', 'jebiacej',
'jebia', 'jebią', 'jebie', 'jebię', 'jebliwy', 'jebnąć', 'jebnac',
'jebnąc', 'jebnać', 'jebnął', 'jebnal', 'jebną', 'jebna', 'jebnęła',
'jebnela', 'jebnie', 'jebnij', 'jebut', 'koorwa', 'kórwa', 'kurestwo',
'kurew', 'kurewski', 'kurewska', 'kurewskiej', 'kurewską', 'kurewska',
'kurewsko', 'kurewstwo', 'kurwa', 'kurwaa', 'kurwami', 'kurwą', 'kurwe',
'kurwę', 'kurwie', 'kurwiska', 'kurwo', 'kurwy', 'kurwach', 'kurwami',
'kurewski', 'kurwiarz', 'kurwiący', 'kurwica', 'kurwić', 'kurwic',
'kurwidołek', 'kurwik', 'kurwiki', 'kurwiszcze', 'kurwiszon',
'kurwiszona', 'kurwiszonem', 'kurwiszony', 'kutas', 'kutasa', 'kutasie',
'kutasem', 'kutasy', 'kutasów', 'kutasow', 'kutasach', 'kutasami',
'matkojebca', 'matkojebcy', 'matkojebcą', 'matkojebca', 'matkojebcami',
'matkojebcach', 'nabarłożyć', 'najebać', 'najebac', 'najebał',
'najebal', 'najebała', 'najebala', 'najebane', 'najebany', 'najebaną',
'najebana', 'najebie', 'najebią', 'najebia', 'naopierdalać',
'naopierdalac', 'naopierdalał', 'naopierdalal', 'naopierdalała',
'naopierdalala', 'naopierdalała', 'napierdalać', 'napierdalac',
'napierdalający', 'napierdalajacy', 'napierdolić', 'napierdolic',
'nawpierdalać', 'nawpierdalac', 'nawpierdalał', 'nawpierdalal',
'nawpierdalała', 'nawpierdalala', 'obsrywać', 'obsrywac', 'obsrywający',
'obsrywajacy', 'odpieprzać', 'odpieprzac', 'odpieprzy', 'odpieprzył',
'odpieprzyl', 'odpieprzyła', 'odpieprzyla', 'odpierdalać',
'odpierdalac', 'odpierdol', 'odpierdolił', 'odpierdolil',
'odpierdoliła', 'odpierdolila', 'odpierdoli', 'odpierdalający',
'odpierdalajacy', 'odpierdalająca', 'odpierdalajaca', 'odpierdolić',
'odpierdolic', 'odpierdoli', 'odpierdolił', 'opieprzający',
'opierdalać', 'opierdalac', 'opierdala', 'opierdalający',
'opierdalajacy', 'opierdol', 'opierdolić', 'opierdolic', 'opierdoli',
'opierdolą', 'opierdola', 'piczka', 'pieprznięty', 'pieprzniety',
'pieprzony', 'pierdel', 'pierdlu', 'pierdolą', 'pierdola', 'pierdolący',
'pierdolacy', 'pierdoląca', 'pierdolaca', 'pierdol', 'pierdole',
'pierdolenie', 'pierdoleniem', 'pierdoleniu', 'pierdolę', 'pierdolec',
'pierdola', 'pierdolą', 'pierdolić', 'pierdolicie', 'pierdolic',
'pierdolił', 'pierdolil', 'pierdoliła', 'pierdolila', 'pierdoli',
'pierdolnięty', 'pierdolniety', 'pierdolisz', 'pierdolnąć',
'pierdolnac', 'pierdolnął', 'pierdolnal', 'pierdolnęła', 'pierdolnela',
'pierdolnie', 'pierdolnięty', 'pierdolnij', 'pierdolnik', 'pierdolona',
'pierdolone', 'pierdolony', 'pierdołki', 'pierdzący', 'pierdzieć',
'pierdziec', 'pizda', 'pizdą', 'pizde', 'pizdę', 'piździe', 'pizdzie',
'pizdnąć', 'pizdnac', 'pizdu', 'podpierdalać', 'podpierdalac',
'podpierdala', 'podpierdalający', 'podpierdalajacy', 'podpierdolić',
'podpierdolic', 'podpierdoli', 'pojeb', 'pojeba', 'pojebami',
'pojebani', 'pojebanego', 'pojebanemu', 'pojebani', 'pojebany',
'pojebanych', 'pojebanym', 'pojebanymi', 'pojebem', 'pojebać',
'pojebac', 'pojebalo', 'popierdala', 'popierdalac', 'popierdalać',
'popierdolić', 'popierdolic', 'popierdoli', 'popierdolonego',
'popierdolonemu', 'popierdolonym', 'popierdolone', 'popierdoleni',
'popierdolony', 'porozpierdalać', 'porozpierdala', 'porozpierdalac',
'poruchac', 'poruchać', 'przejebać', 'przejebane', 'przejebac',
'przyjebali', 'przepierdalać', 'przepierdalac', 'przepierdala',
'przepierdalający', 'przepierdalajacy', 'przepierdalająca',
'przepierdalajaca', 'przepierdolić', 'przepierdolic', 'przyjebać',
'przyjebac', 'przyjebie', 'przyjebała', 'przyjebala', 'przyjebał',
'przyjebal', 'przypieprzać', 'przypieprzac', 'przypieprzający',
'przypieprzajacy', 'przypieprzająca', 'przypieprzajaca',
'przypierdalać', 'przypierdalac', 'przypierdala', 'przypierdoli',
'przypierdalający', 'przypierdalajacy', 'przypierdolić',
'przypierdolic', 'qrwa', 'rozjebać', 'rozjebac', 'rozjebie',
'rozjebała', 'rozjebią', 'rozpierdalać', 'rozpierdalac', 'rozpierdala',
'rozpierdolić', 'rozpierdolic', 'rozpierdole', 'rozpierdoli',
'rozpierducha', 'skurwić', 'skurwiel', 'skurwiela', 'skurwielem',
'skurwielu', 'skurwysyn', 'skurwysynów', 'skurwysynow', 'skurwysyna',
'skurwysynem', 'skurwysynu', 'skurwysyny', 'skurwysyński',
'skurwysynski', 'skurwysyństwo', 'skurwysynstwo', 'spieprzać',
'spieprzac', 'spieprza', 'spieprzaj', 'spieprzajcie', 'spieprzają',
'spieprzaja', 'spieprzający', 'spieprzajacy', 'spieprzająca',
'spieprzajaca', 'spierdalać', 'spierdalac', 'spierdala', 'spierdalał',
'spierdalała', 'spierdalal', 'spierdalalcie', 'spierdalala',
'spierdalający', 'spierdalajacy', 'spierdolić', 'spierdolic',
'spierdoli', 'spierdoliła', 'spierdoliło', 'spierdolą', 'spierdola',
'srać', 'srac', 'srający', 'srajacy', 'srając', 'srajac', 'sraj',
'sukinsyn', 'sukinsyny', 'sukinsynom', 'sukinsynowi', 'sukinsynów',
'sukinsynow', 'śmierdziel', 'udupić', 'ujebać', 'ujebac', 'ujebał',
'ujebal', 'ujebana', 'ujebany', 'ujebie', 'ujebała', 'ujebala',
'upierdalać', 'upierdalac', 'upierdala', 'upierdoli', 'upierdolić',
'upierdolic', 'upierdoli', 'upierdolą', 'upierdola', 'upierdoleni',
'wjebać', 'wjebac', 'wjebie', 'wjebią', 'wjebia', 'wjebiemy',
'wjebiecie', 'wkurwiać', 'wkurwiac', 'wkurwi', 'wkurwia', 'wkurwiał',
'wkurwial', 'wkurwiający', 'wkurwiajacy', 'wkurwiająca', 'wkurwiajaca',
'wkurwić', 'wkurwic', 'wkurwi', 'wkurwiacie', 'wkurwiają', 'wkurwiali',
'wkurwią', 'wkurwia', 'wkurwimy', 'wkurwicie', 'wkurwiacie', 'wkurwić',
'wkurwic', 'wkurwia', 'wpierdalać', 'wpierdalac', 'wpierdalający',
'wpierdalajacy', 'wpierdol', 'wpierdolić', 'wpierdolic', 'wpizdu',
'wyjebać', 'wyjebac', 'wyjebali', 'wyjebał', 'wyjebac', 'wyjebała',
'wyjebały', 'wyjebie', 'wyjebią', 'wyjebia', 'wyjebiesz', 'wyjebie',
'wyjebiecie', 'wyjebiemy', 'wypieprzać', 'wypieprzac', 'wypieprza',
'wypieprzał', 'wypieprzal', 'wypieprzała', 'wypieprzala', 'wypieprzy',
'wypieprzyła', 'wypieprzyla', 'wypieprzył', 'wypieprzyl', 'wypierdal',
'wypierdalać', 'wypierdalac', 'wypierdala', 'wypierdalaj',
'wypierdalał', 'wypierdalal', 'wypierdalała', 'wypierdalala',
'wypierdalać', 'wypierdolić', 'wypierdolic', 'wypierdoli',
'wypierdolimy', 'wypierdolicie', 'wypierdolą', 'wypierdola',
'wypierdolili', 'wypierdolił', 'wypierdolil', 'wypierdoliła',
'wypierdolila', 'zajebać', 'zajebac', 'zajebie', 'zajebią', 'zajebia',
'zajebiał', 'zajebial', 'zajebała', 'zajebiala', 'zajebali', 'zajebana',
'zajebani', 'zajebane', 'zajebany', 'zajebanych', 'zajebanym',
'zajebanymi', 'zajebiste', 'zajebisty', 'zajebistych', 'zajebista',
'zajebistym', 'zajebistymi', 'zajebiście', 'zajebiscie', 'zapieprzyć',
'zapieprzyc', 'zapieprzy', 'zapieprzył', 'zapieprzyl', 'zapieprzyła',
'zapieprzyla', 'zapieprzą', 'zapieprza', 'zapieprzy', 'zapieprzymy',
'zapieprzycie', 'zapieprzysz', 'zapierdala', 'zapierdalać',
'zapierdalac', 'zapierdalaja', 'zapierdalał', 'zapierdalaj',
'zapierdalajcie', 'zapierdalała', 'zapierdalala', 'zapierdalali',
'zapierdalający', 'zapierdalajacy', 'zapierdolić', 'zapierdolic',
'zapierdoli', 'zapierdolił', 'zapierdolil', 'zapierdoliła',
'zapierdolila', 'zapierdolą', 'zapierdola', 'zapierniczać',
'zapierniczający', 'zasrać', 'zasranym', 'zasrywać', 'zasrywający',
'zesrywać', 'zesrywający', 'zjebać', 'zjebac', 'zjebał', 'zjebal',
'zjebała', 'zjebala', 'zjebana', 'zjebią', 'zjebali', 'zjeby',
'[ WŁAŚCICIEL ]', '[ TECHNIK ]', '[ ROOT ]', '[ SUPPORT ]',
'Adolf Hitler', 'TeamSpeakUser', 'Hitler', '.pl', '.eu', '.com',
'Stalin', 'Józef Stalin') //Niedozwolone wyrazy
	),
	
//Funkcja serverName wpisuje w nazwę serwera ilość użytkowników online
	'serverName' => array(
		'enabled' => true, //Wlaczyc czy wylaczyc funkcje	
		'name' => 'SBOT - online: [online]', //Nazwa serwera // [online] - ilosc osób online // [max] - maksymalna ilosc osób online
		'interval' => array('days' => 0,'hours' => 0,'minutes' => 0,'seconds' => 15)
		),
	
	//Funkcja welcomeMessage wysyła wiadomość powitalną do użytkownika po wejściu na serwer
	'welcomeMessage' => array(
		'enabled' => true, //Wlaczyc czy wylaczyc funkcje
	),
	
	//Funkcja createFreeChannels tworzy wolne kanały w strefie prywatnej jeżeli ich ilość jest mniejsza niż ustalona
	'createFreeChannels' => array(
		'enabled' => true, //Wlaczyc czy wylaczyc
		'pid' => 116, //ID strefy kanalow prywatnych
		'minFreeChannels' => 5, //Ile ma byc minimalnie wolnych kanalow prywatnych
		'freeChannelName' => 'KANAŁ PRYWATNY [ WOLNY ]' //Nazwa wolnego kanalu prywtanego
	),
	
	//Funkcja adminsOnline generuje listę administracji online w danym momencie
	'adminsOnline' => array(
		'enabled' => true,
		'adminsGroups' => array(11,13,14,15,16,17),
		'cid' => 48,
		'channelName' => '[cspacer]• Dostępni Administratorzy: [adminsOnline] •',
		'interval' => array('days' => 0,'hours' => 0,'minutes' => 0,'seconds' => 20) //Co jaki czas ma edytowac administracje online
	),
	
	//Funkcja groupOnline wypisuje ilość użytkowników online z danej grupy w nazwę kanału oraz ich listę w opis
	'groupOnline' => array(
		'enabled' => false, //Wlaczyc czy wylaczyc
		'channels' => array(
			0 => array(                                  //id (nie ma znaczenia, byle bylo w dobrej kolejnosci) => array (
				'group' => array(57),                    //'group' => array(id grupy),
				'cid' => 339,                            //'cid' => id kanalu, na ktorym ma wpisiywac osoby i ilosc online z danej grupy,
				'channelName' => '[cspacer]♦ ONILNE Z XXX: [online]/[total] ♦ '    //'channelName' => ''
			),
		)

	),
	
	//Funkcja clanGroup nadaje rangę klanową po wejsciu na odpowiedni kanał, a gdy użytkownik posiada już rangę klanową, bot zabiera mu ją
	'clanGroup' => array(
		'enabled' => false, //Wlaczyc czy wylaczyc
		'channels' => array(
 			340 => array(57), //id kanalu => array(id grupy),
		)
	),
	
	//Funkcja adminStatusOnChannel wpisuje status administracji w nazwę kanału
	'adminStatusOnChannel' => array(
		'enabled' => false, //Wlaczyc czy wylaczyc
		'channels' => array(
			0 => array(                                      //Adrian id (nie ma znaczenia, byle bylo w dobrej kolejnosci) => array (
				'uid' => 'eQ3QHktI8Z14YA27rRu1P8KXqHw=',     //'uid' => 'uid administratora',
				'cid' => 363                                 //'cid' => 'id kanalu administratora, w ktorego nazwe bedzie wpisywany jego status'
			),
			
		),
		'adminsGroups' => array(10,11,12,78),  //Wszystkie grupy administracyjne
		'format' => '[[group]] [nick] - [status]'   //Format wyswietlania statusu na kanale (np. [QUERY] ArrMeeR - Online) #Znaczniki: [group] - grupa administartora # [nick] - nick administratora # [status] - status administratora
	),
	
	//Funkcja fillGapsInChannels uzupełnia luki w kanałach prywatnych
	'fillGapsInChannels' => array(
		'enabled' => true, //Wlaczyc czy wylaczyc
		'pid' => 116 //ID stredy prywatnej
	),

);

?> 
