<?php

class adminList
{
	function start()
	{
		global $query;
		global $config;
		global $instanceid;
		
		$adminsgroups = $config[$instanceid]['functions']['adminList']['adminsGroups'];
	
		$desc = '[center][size=13]Lista Administracji:[/size][/center]\n\n';
	foreach($adminsgroups as $group)
	{
		$group_name = self::getgroupname($group);
		$groupsclients = $query->getElement('data', $query->serverGroupClientList($group, $names = true));
		$clients = $query->getElement('data', $query->clientList("-uid -groups -times"));
		$desc.= '[size=13][b][' . $group_name . '][/b]:[/size]';
		if (!array_key_exists('client_nickname', $groupsclients[0]))
		{
			$desc .= '[list][*][size=9] Brak administracji w tej grupie [/size][/list]';
		}
		if (array_key_exists('client_nickname', $groupsclients[0]))
		{
			foreach($groupsclients as $groupclient)
			{
				foreach($clients as $client)
				{
					if ($client['client_unique_identifier'] == $groupclient['client_unique_identifier'])
					{
						$online = true;
						break;
					}
					else
					{
						$online = false;
					}
				}

					if ($online)
					{
						$desc.= '[list][*][url=client://' . $client['clid'] . '/' . $groupclient['client_unique_identifier'] . '][b][size=9]' . $groupclient['client_nickname'] . '[/b][/url][size=9] jest aktualnie [img]https://i.imgur.com/ykdep4j.png[/img][/size][/list]';
						
					}
					else
					{
						$info = $query->getElement('data', $query->clientDbInfo($groupclient['cldbid']));
						//$seconds = time() - $info['client_lastconnected'];
						$seconds = time() - $info['client_lastconnected'];

						$days    = floor($seconds / 86400);
						$hours   = floor(($seconds - ($days * 86400)) / 3600);
						$minutes = floor(($seconds - ($days * 86400) - ($hours * 3600))/60);
						$seconds = floor(($seconds - ($days * 86400) - ($hours * 3600) - ($minutes*60)));
						$time = '';
						if($days>0)
						{
							$time .= ''.$days.' dni ';
						}
						if($hours>0)
						{
							$time .= ''.$hours.' godzin ';
						}
						if($minutes>0)
						{
							$time .= ''.$minutes.' minut';
						}
						if($time=='')
						{
							$time .= ''.$seconds.' sekund';
						}
						$desc.= '[list][*][url=client://' . $client['clid'] . '/' . $groupclient['client_unique_identifier'] . '][b][size=9]' . $groupclient['client_nickname'] . '[/b][/url][size=9] jest aktualnie [img]https://i.imgur.com/Sj8qlHN.png[/img][/size][/list]';
						$desc .= '[hr][right]Wygenerowane przez [b]SBot[/b][/right]';
					
					}
				}
			

			
		}
	}
	$desc.= '\n';
	$desc.= '[hr]';
	$desc.= '';
	$channel = $query->channelInfo($config[$instanceid]['functions']['adminList']['channel']);
	if (strcmp($channel['data']['channel_description'], $desc) != 0)
	{
		$query->channelEdit($config[$instanceid]['functions']['adminList']['channel'], array(
			'channel_description' => $desc
		));
	}
}

function getgroupname($grupa)
{
	global $query;
	$groups = $query->getElement('data', $query->serverGroupList());
	$groupname = '';
	foreach($groups as $group)
	{
		if ($group['sgid'] == $grupa)
		{
			$groupname = $group['name'];
		}
	}

	return $groupname;
}
}

?> 
