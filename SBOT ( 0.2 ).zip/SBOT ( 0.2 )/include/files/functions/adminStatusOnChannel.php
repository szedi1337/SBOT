<?php
 
class adminStatusOnChannel
{
    function start()
    {
        global $query;
        global $config;
        global $instanceid;
       
        $users = array();
        $uids = array();
        $groups = array();
       
       
        foreach($config[$instanceid]['functions']['adminStatusOnChannel']['adminsGroups'] as $sgid)
        {
            $user = $query->getElement('data', $query->serverGroupClientList($sgid, $names = true));
 
           
            foreach($user as $client)
            {
            if(array_key_exists('client_nickname', $client))
            {
                array_push($users, $client['client_nickname']);
                array_push($uids, $client['client_unique_identifier']);
                array_push($groups, $sgid);
            }
            }
           
        }
   
       
        foreach($config[$instanceid]['functions']['adminStatusOnChannel']['channels'] as $channel)
        {
        for($i=0; $i<count($users); $i++)
        {
        if($uids[$i]==$channel['uid'])
        {
            foreach($query->getElement('data', $query->clientList("-uid -away -voice -times -groups -info -icon -ip")) as $client)
            {
            if($client['client_unique_identifier']==$channel['uid'])
            {
                if($client['client_away']==1 || $client['client_output_muted']==1)
                {
                    $status = 'AFK';
                   
                    break;
                }
                else
                {
                $status = 'Online';
                break;
                }
            }
            else
            {
                $status = 'Offline';
               
            }
 
            }
       
       
 
            $name = str_replace(array('[group]','[nick]','[status]'), array(self::getGroupName($groups[$i]), $users[$i], $status), $config[$instanceid]['functions']['adminStatusOnChannel']['format']);
			$desc .= '[hr][right]Wygenerowane przez [b]SBot[/b][/right]';
            $query->channelEdit($channel['cid'], array('channel_name'=>$name));
			
   
        }
        }
        }
   
    }
   
function getGroupName($grupa)
{
    global $query;
    $groups = $query->getElement('data', $query->serverGroupList());
    $groupname = '';
    foreach($groups as $group)
    {
        if ($group['sgid'] == $grupa)
        {
            $groupname = $group['name'];
        }
    }
 
    return $groupname;
}
 
}
 
?>