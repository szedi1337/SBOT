<?php

class adminsOnline
{
	function start()
	{
		global $query;
		global $config;
		global $instanceid;
		global $instance;
		
		$admins = 0;
		$adminsNicks = array();
		$adminsClid = array();
		$adminsUid = array();
		$adminsGroups = array();
		
		$users = $query->getElement('data',$query->clientList('-groups -voice -away -times -uid'));
		
		foreach($config[$instanceid]['functions']['adminsOnline']['adminsGroups'] as $sgid)
		{
			$user = $query->getElement('data', $query->serverGroupClientList($sgid, $names = true));

			
			foreach($user as $client)
			{
			if(array_key_exists('client_nickname', $client))
			{
				array_push($adminsNicks, $client['client_nickname']);
				array_push($adminsUid, $client['client_unique_identifier']);
				
				array_push($adminsGroups, $sgid);
				
				foreach($users as $status)
				{
					if($status['client_unique_identifier']==$client['client_unique_identifier'])
					{
						$admins++;
						break;
					}
					else
					{
						
					}
				}
				
			}
			}
			
		}
	
	
	
	$desc = '[center][size=13]Adminów [color=green]Online[/color]: '.$admins.'[/size] \n';
	$desc .= '[/center]';
	for($i=0; $i<count($adminsNicks); $i++)
	{
		$ids = $query->getElement('data', $query->clientGetIds($adminsUid[$i]));
		
		if($ids)
		{
		foreach($ids as $id)
		{
			$info = $query->getElement('data', $query->clientInfo($id['clid']));
			$online  = true;
			break;
			
		}
		}
		else
		{
			
			$online = false;
		}

			if($online)
	{	
		$connectionTime = '';
$init = $info['connection_connected_time']/1000;
$hours = floor($init / 3600);
$minutes = floor(($init / 60) % 60);
$seconds = $init % 60;

	if($hours>0)
	{
		$connectionTime .= ''.$hours.' godzin ';
	}
	if($minutes>0)
	{
		$connectionTime .= ''.$minutes.' minut ';
	}
	if($seconds>0)
	{
		$connectionTime .= ''.$seconds.' sekund';
	}
	
	$channelInfo = $query->getElement('data', $query->channelInfo($info['cid']));


	
	


		$desc .= '[list][*][size=10]['.self::getGroupName($adminsGroups[$i]).'] [url=client://0/'.$adminsUid[$i].'][b]'.$adminsNicks[$i].'[/b][/url] jest [img]https://i.imgur.com/ykdep4j.png[/img] od [b]'.$connectionTime.'[/b] na kanale [b][url=channelID://'.$info['cid'].']'.$channelInfo['channel_name'].'[/url][/b][/list]';
		$desc .= '[hr][right]Wygenerowane przez [b]SBot[/b][/right]';
	}
	}

	

	$desc .= '[hr]';
	$desc.= '';
	$adminsOnline = array();
	$adminsOnline['channel_name'] = str_replace('[adminsOnline]', $admins, $config[$instanceid]['functions']['adminsOnline']['channelName']);
	$adminsOnline['channel_description'] = $desc;
	
	
		$query->channelEdit($config[$instanceid]['functions']['adminsOnline']['cid'], array(
			'channel_name' => $adminsOnline['channel_name']
		));
		
	$channel = $query->channelInfo($config[$instanceid]['functions']['adminsOnline']['cid']);
	if (strcmp($channel['data']['channel_description'], $desc) != 0)
	{
		$query->channelEdit($config[$instanceid]['functions']['adminsOnline']['cid'], array(
			'channel_description' => $desc,
		));
	}
	
	}
	
	function getGroupName($grupa)
	{
	global $query;
	$groups = $query->getElement('data', $query->serverGroupList());
	$groupname = '';
	foreach($groups as $group)
	{
		if ($group['sgid'] == $grupa)
		{
			$groupname = $group['name'];
		}
	}

	return $groupname;
	}
}

?> 
