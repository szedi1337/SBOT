<?php

class afkChecker
{
	function start()
	{
	global $query;
	global $config;
	global $instanceid;
	global $clientchannel;
	global $instance;
	
	$users = $query->getElement('data',$query->clientList('-groups -voice -away -times -uid'));
	
	foreach ($users as $client)
	{
	$idle = $client['client_idle_time'];
	$time = $config[$instanceid]['functions']['afkChecker']['afkTime'];
	$group = $config[$instanceid]['functions']['afkChecker']['afkGroup'];
	$user_groups = explode(',',$client['client_servergroups']);
	if($client['client_type']==0)
	{
	if(!$instance->isInGroup($user_groups,$config[$instanceid]['functions']['afkChecker']['ignoredGroups']))
	{
	if($client['client_output_muted']==1 || $client['client_away']==1)
    {
	if($config[$instanceid]['functions']['afkChecker']['moveToAFKchannel'] && $client['cid']!=$config[$instanceid]['functions']['afkChecker']['afkChannel'])
	{

	$clientchannel[$client['client_unique_identifier']] = $client['cid'];
	$query->clientMove($client['clid'], $config[$instanceid]['functions']['afkChecker']['afkChannel']);
	
	}
	}
	else
	{
	if($config[$instanceid]['functions']['afkChecker']['moveToAFKchannel'] && isset($clientchannel[$client['client_unique_identifier']]))
	{
	$query->clientMove($client['clid'], $clientchannel[$client['client_unique_identifier']]);
	unset($clientchannel[$client['client_unique_identifier']]);
	}
	}
	
	if($config[$instanceid]['functions']['afkChecker']['addAFKgroup'])
	{
		if($idle>$time*60000)
		{
	$query->serverGroupAddClient($group, $client['client_database_id']);
		}
		else
		{
			$query->serverGroupDeleteClient($group, $client['client_database_id']);
		}
	}
	}
	}
	}
	}
	
}

?> 
