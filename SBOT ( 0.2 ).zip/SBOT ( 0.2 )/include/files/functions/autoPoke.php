<?php

class autoPoke
{
	function start()
	{
		global $query;
		global $config;
		global $instanceid;
		global $admins;
		$users = $query->getElement('data',$query->clientList('-groups -voice -away -times'));
		
		foreach ($users as $client) {              
                $user_groups = explode(',',$client['client_servergroups']);
                
				if (self::isInGroup($user_groups,$config[$instanceid]['functions']['autoPoke']['adminsGroups'])) {
                    $admins[$client['clid']] = $client['clid'];
                }
				
                if (array_key_exists($client['cid'],$config[$instanceid]['functions']['autoPoke']['poke_settings']) && !self::isInGroup($user_groups, $config[$instanceid]['functions']['autoPoke']['adminsGroups']) && !$client['client_is_talker']) {
                    
						if($admins!=null)
						{
                        $query->sendMessage(1, $client['clid'],'\n Administracja została powiadomiona o Twoim pobycie na kanale \n Prosimy o cierpliwość, wkrótce zostanie udzielona Ci pomoc! \n [b]Aspeak.eu[/b]',true);
						}
						else
						{
						 $query->sendMessage(1, $client['clid'],'\n Drogi użytkowniku aktualnie nie ma żadnego Administratora.\n Zapraszamy ponownie pózniej!\n [b]Aspeak.eu[/b] ',true);
						}
						foreach((array)$admins as $admin)
						{
						$query->clientPoke($admin,'Użytkownik o nicku '.$client['client_nickname'].' oczekuje na Twoją pomoc!');
						$admins = null;
						}
                }

				
            
        }
	}
	
	function isInGroup($usergroups,$group) {
    $diff = count(array_diff($usergroups, $group));
    
    if ($diff < count($usergroups)) {
        return true;
    }
    else {
        return false;
    }
}
}

?>  
