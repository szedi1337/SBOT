
<?php
class channelChecker

{
	function start()
	{
		global $config;
		global $query;
		global $instanceid;
		$channels = $query->getElement('data', $query->channelList('-topic -limits'));
		$time = time();
		$mainChannels = array();
		foreach($channels as $channel)
		{
			if ($channel['pid'] == $config[$instanceid]['functions']['channelChecker']['pid'])
			{
				if ($channel['channel_topic'] != 'wolny')
				{
					array_push($mainChannels, $channel['cid']);
					if ($channel['channel_topic'] == '')
					{
						$oneDay = strtotime("+1 days", $time);
						$query->channelEdit($channel['cid'], array(
							'channel_topic' => date('d.m.Y', $oneDay)
						));
						break;
					}

					if ($channel['total_clients'] > 0)
					{
						$channelExpireDate = $channel['channel_topic'];
						$channelExpireDate = strtotime($channelExpireDate);
						if ($channelExpireDate < strtotime("-1 days"))
						{
							$sevenDays = strtotime("+7 days", $time);
							$newChannelExpireDate = date("d.m.Y", $sevenDays);
							$query->channelEdit($channel['cid'], array(
								'channel_topic' => $newChannelExpireDate
							));
						}
					}

					if ($channel['total_clients'] == 0)
					{
						$channelExpireDate = $channel['channel_topic'];
						$channelExpireDate = strtotime($channelExpireDate);
						if ($channelExpireDate < strtotime("-7 days"))
						{
							$channelNumber = (int)$channel['channel_name'];
							$order = $channel['channel_order'];
							$query->channelDelete($channel['cid'], 1);
							$query->channelCreate(array(
								'channel_flag_permanent' => 1,
								'cpid' => $config[$instanceid]['functions']['channelChecker']['pid'],
								'channel_name' => '' . $channelNumber . '. KANAŁ PRYWATNY [ WOLNY ]',
								'channel_maxclients' => 0,
								'channel_maxfamilyclients' => 0,
								'channel_flag_maxclients_unlimited' => 0,
								'channel_flag_maxfamilyclients_unlimited' => 0,
								'channel_flag_maxfamilyclients_inherited' => 0,
								'channel_topic' => 'wolny',
								'channel_description' => '[hr]\n[center][size=15][b][color=red]KANAŁ PRYWATNY[/color][/b][/size][/center]\n[hr]\n[center][color=darkorange][b][size=15]#WOLNY![/size][/b][/color]\n\n\n[hr]',
								'channel_description' => '[hr][right]Wygenerowane przez [b]SBot[/b][/right]',
								'channel_order' => $order
							));
						}
					}
				}
			}

			foreach($mainChannels as $mainChannel)
			{
				if ($channel['pid'] == $mainChannel)
				{
					$info = $query->getElement('data', $query->channelInfo($mainChannel));
					if ($channel['total_clients'] > 0)
					{
						$channelExpireDate = $info['channel_topic'];
						$channelExpireDate = strtotime($channelExpireDate);
						if ($channelExpireDate < strtotime("-1 days"))
						{
							$sevenDays = strtotime("+7 days", $time);
							$newChannelExpireDate = date("d.m.Y", $sevenDays);
							$query->channelEdit($mainChannel, array(
								'channel_topic' => $newChannelExpireDate
							));
						}
					}

					$channelExpireDate = $info['channel_topic'];
					$channelExpireDate = strtotime($channelExpireDate);
					if ($channelExpireDate < strtotime("-7 days"))
					{
					}
				}
			}
		}
	}
}

?>
