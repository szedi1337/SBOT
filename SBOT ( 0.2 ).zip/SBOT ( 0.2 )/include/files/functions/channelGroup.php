<?php
class channelGroup

{
	function start()
	{
		global $query;
		global $config;
		global $instanceid;
		global $instance;
		$array = $config[$instanceid]['functions']['channelGroup']['channels'];
		$clients = $query->getElement('data', $query->clientList('-groups'));
		foreach($clients as $client)
		{
			foreach($config[$instanceid]['functions']['channelGroup']['channels'] as $key => $value)
			{
				if ($client['cid'] == $key)
				{
					$clientinfo = $query->getElement('data', $query->clientInfo($client['clid']));
					$groups = explode(',', $clientinfo['client_servergroups']);
					if(!$instance->isInGroup($groups, $config[$instanceid]['functions']['channelGroup']['allGroups']))
					{
					$query->serverGroupAddClient($value, $clientinfo['client_database_id']);
					}
					else
					{
					$query->clientKick($client['clid'], 'channel', 'Jesteś już zarejestrowany!');
					$query->clientPoke($client['clid'], 'Jesteś już zarejestrowany!');
					}
				}
			}
		}
	}
}

?> 
