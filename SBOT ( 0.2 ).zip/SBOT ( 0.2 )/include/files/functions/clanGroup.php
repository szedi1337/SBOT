<?php

class clanGroup
{
	function start()
	{
		global $query;
		global $config;
		global $instanceid;
		global $instance;
		
		$array = $config[$instanceid]['functions']['clanGroup']['channels'];
		$clients = $query->getElement('data', $query->clientList());
		foreach($clients as $client)
		{
			foreach($config[$instanceid]['functions']['clanGroup']['channels'] as $key => $value)
			{
				if ($client['cid'] == $key)
				{
					$clientinfo = $query->getElement('data', $query->clientInfo($client['clid']));
					$groups = explode(',', $clientinfo['client_servergroups']);
					if(!$instance->isInGroup($groups, $value))
					{
					$query->serverGroupAddClient($value[0], $clientinfo['client_database_id']);
					$query->clientKick($client['clid'], 'channel', 'Ranga została nadana!');
					}
					else
					{
					$query->serverGroupDeleteClient($value[0], $clientinfo['client_database_id']);
					$query->clientKick($client['clid'], 'channel', 'Ranga została odebrana!');
					}
				}
			}
		}
	}
}

?>