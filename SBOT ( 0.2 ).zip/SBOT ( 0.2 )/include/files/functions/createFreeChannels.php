<?php

class createFreeChannels
{
	function start()
	{
		global $config;
		global $query;	
		global $instanceid;
		
		$channels = $query->getElement('data', $query->channelList('-topic -limits'));
		
		$freeChannels = 0;
		$channelNumbers = array();
		foreach($channels as $channel)
		{
			if($channel['channel_topic']=='wolny')
			{
				$freeChannels++;
							$number = (int)$channel['channel_name'];
			array_push($channelNumbers, $number);
			}

		}
				$lastChannel = end($channelNumbers);
				$lastChannel = $lastChannel+1;
		
			if($freeChannels<$config[$instanceid]['functions']['createFreeChannels']['minFreeChannels'])
			{
				$desc = '[hr]\n[center][size=15][b][color=red]KANAŁ PRYWATNY[/color][/b][/size][/center]\n[hr]\n[center][color=darkorange][b][size=15]#WOLNY![/size][/b][/color]\n\n\n[hr][/center]';
				$desc = '[hr][right]Wygenerowane przez [b]SBot[/b][/right]';
			$query->channelCreate(array('channel_flag_permanent' => 1, 'cpid' => $config[$instanceid]['functions']['createFreeChannels']['pid'], 'channel_name' => ''.$lastChannel.'. KANAŁ PRYWATNY [ WOLNY ]', 'channel_maxclients'=>0, 'channel_maxfamilyclients'=>0, 'channel_flag_maxclients_unlimited'=>0, 'channel_flag_maxfamilyclients_unlimited'=>0, 'channel_flag_maxfamilyclients_inherited'=>0, 'channel_topic'=>'wolny', 'channel_description'=>$desc));
				
			}

	}
}

?> 
