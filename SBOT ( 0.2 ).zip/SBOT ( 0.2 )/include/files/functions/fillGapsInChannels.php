<?php

class fillGapsInChannels
{
	function start()
	{
		
		global $query;
		global $instanceid;
		global $config;
		global $instance;
		
		$channels = $query->getElement('data', $query->channelList());
		
		$numbers = array();
		
		foreach($channels as $channel)
		{
			if($channel['pid']==$config[$instanceid]['functions']['fillGapsInChannels']['pid'])
			{
				$number = (int)$channel['channel_name'];
				array_push($numbers, $number);
				
			}
		

		}
		$arr2 = range(1,max($numbers));                                                    

		
		$missing = array_diff($arr2,$numbers);
		
		
		foreach($missing as $channelNumber)
		{
			$previousOrder = $channelNumber-1;
			
			
			
			foreach($channels as $channel)
			{
				if((int)$channel['channel_name']==$previousOrder && $channel['pid']==$config[$instanceid]['functions']['fillGapsInChannels']['pid'])
				{
					$previousOrder = $channel['cid'];
					
					$query->channelCreate(array('channel_flag_permanent' => 1, 'cpid' => $config[$instanceid]['functions']['fillGapsInChannels']['pid'], 'channel_name' => ''.$channelNumber.'. KANAŁ PRYWATNY [ WOLNY ]', 'channel_maxclients'=>0, 'channel_maxfamilyclients'=>0, 'channel_flag_maxclients_unlimited'=>0, 'channel_flag_maxfamilyclients_unlimited'=>0, 'channel_flag_maxfamilyclients_inherited'=>0, 'channel_topic'=>'wolny', 'channel_description' => '[hr]\n[center][size=15][b][color=red]KANAŁ PRYWATNY[/color][/b][/size][/center]\n[hr]\n[center][color=darkorange][b][size=15]#WOLNY![/size][/b][/color]\n\n\n[hr][/center]', 'channel_order'=>$previousOrder));

				}
			}
		}
		
	}
}

?> 
