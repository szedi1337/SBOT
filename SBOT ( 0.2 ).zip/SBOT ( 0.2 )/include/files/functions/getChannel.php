<?php

class getChannel
{
	function start()
	{
		global $config;
		global $query;	
		global $instanceid;
		

$clients = $query->getElement('data', $query->clientList('-groups'));
foreach($clients as $client)
{
$channel = $query->getElement('data', $query->channelList('-topic -limits'));
  foreach($channel as $channels)
  {
	  if($client['cid']==$config[$instanceid]['functions']['getChannel']['cid'])
	  {

		 $groups = explode(",", $client['client_servergroups']);
		 if(self::isInGroup($groups, $config[$instanceid]['functions']['getChannel']['groups']))
		 {
			
		  $cglist = $query->getElement('data', $query->channelGroupClientList(null, $client['client_database_id'], $config[$instanceid]['functions']['getChannel']['channelGroup']));

			
			$canget = false;
			if($cglist[0]==null)
			{
				$canget = true;
			}
			else
			{
				$userChannel = $cglist[0]['cid'];
			}


			if($canget == false)
			 {

				$query->sendMessage(1, $client['clid'], 'Posiadasz już u nas kanał prywatny! Zostałeś na niego przeniesiony');
				$query->clientMove($client['clid'], $userChannel);
				
				break 2;
			
			}
			 
			else
			{

		if($channels['channel_topic']=='wolny')
		{
			$query->sendMessage(1, $client['clid'], 'Zostałeś przeniesiony na Twój nowy kanał. Zmień hasło oraz nazwe kanału. Zostały stworzone [b]'.$config[$instanceid]['functions']['getChannel']['subChannels'].'[/b] podkanały');
			$query->clientMove($client['clid'], $channels['cid']);
			$query->setClientChannelGroup($config[$instanceid]['functions']['getChannel']['channelGroup'], $channels['cid'], $client['client_database_id']);
			$number = (integer)$channels['channel_name'];
			$desc = '[hr]\n[center][size=15][b][color=red]KANAŁ PRYWATNY[/color][/b][/size][/center]\n[hr]\n[center][color=darkorange][b][size=15]#'.$number.'[/size][/b][/color]\n\n\n[color=darkorange][b]WŁAŚCICIEL KANAŁU:[/b][/color]\n'.$client['client_nickname'].'\n\n[color=darkorange][b]DATA UTWORZENIA:[/b][/color]\n' . date("d.m.y", time()) . '\n\n\n[hr][/center]';
			$desc = '[hr][right]Wygenerowane przez [b]SBot[/b][/right]'
			$query->channelEdit($channels['cid'], array('channel_name' => ''.$number.'. KANAŁ '.$client['client_nickname'].''));
			$time = strtotime("+7 days",time());
			$query->channelEdit($channels['cid'], array('channel_description' => $desc, 'channel_flag_maxclients_unlimited' => 1, 'channel_flag_maxfamilyclients_unlimited' => 1, 'channel_maxclients' => 1, 'channel_maxfamilyclients' => 1, 'channel_topic'=>date("d.m.Y", $time)));
			for($i=0; $i<$config[$instanceid]['functions']['getChannel']['subChannels']; $i++)
			{
			$numer = $i;
			$numer++;
			$query->channelCreate(array('channel_flag_permanent' => 1, 'cpid' => $channels['cid'], 'channel_name' => ''.$numer.'. PODKANAŁ', 'channel_flag_maxclients_unlimited' => 1, 'channel_flag_maxfamilyclients_unlimited' => 1, 'channel_maxclients' => 1, 'channel_maxfamilyclients' => 1,));
			}
			break 2;
		}
		 
		  }
		  
		  
		
		  
		 }
		  else
		  {
			  $query->sendMessage(1, $client['clid'], 'Nie posiadasz rang wymaganych do założenia kanału prywatnego!');
			  $query->clientKick($client['clid'], 'channel');
			  break;
		  }
		 }
	  
	}
  
}
	}
	
	function isInGroup($usergroups,$group) {
    $diff = count(array_diff($usergroups, $group));
    
    if ($diff < count($usergroups)) {
        return true;
    }
    else {
        return false;
    }
}
}

?> 
