<?php

class groupOnline
{
	function start()
	{
		global $query;
		global $config;
		global $instanceid;
		global $instance;
		
		$online = 0;
		$nicks = array();
		$clid = array();
		$uid = array();
		
		$users = $query->getElement('data',$query->clientList('-groups -voice -away -times -uid'));
		
		
	for($i=0; $i<count($config[$instanceid]['functions']['groupOnline']['channels']); $i++)
	{
				$online = 0;
		$nicks = array();
		$clid = array();
		$uid = array();
		
		$sgClList = $query->getElement('data', $query->serverGroupClientList($config[$instanceid]['functions']['groupOnline']['channels'][$i]['group'][0], true));
		$usersInGroup = count($sgClList);

		foreach ($users as $client) {              
                $user_groups = explode(',',$client['client_servergroups']);
                
				if ($instance->isInGroup($user_groups,$config[$instanceid]['functions']['groupOnline']['channels'][$i]['group'])) {
					$online++;

					array_push($nicks, $client['client_nickname']);
					array_push($clid, $client['clid']);
					array_push($uid, $client['client_unique_identifier']);
				}
		}
	
	$desc = '[hr]\n[center][size=15][b][color=white]UŻYTKOWNICY ONLINE: '.$online.'/'.$usersInGroup.'[/color][/b][/size][/center]\n[hr]\n';
	foreach($sgClList as $cl)
	{
		foreach($users as $client)
		{
			
		if($client['client_unique_identifier']==$cl['client_unique_identifier'])
		{
		$status = '[img]https://i.imgur.com/98H42ZT.png[/img]';
		
		break;
		}
		else
		{
		$status = '[img]https://i.imgur.com/0nzHCRu.png[/img]';
		}
		
		}
		$desc .= '[list][*][url=client://0/'.$cl['client_unique_identifier'].'][color=darkorange][b]'.$cl['client_nickname'].'[/b][/color][/url] jest aktualnie '.$status.'[/list]';
		$desc = '[hr][right]Wygenerowane przez [b]SBot[/b][/right]'
	}

	

	
	$channel = array();
	$channel['channel_name'] = str_replace(array('[online]','[total]'), array($online,$usersInGroup), $config[$instanceid]['functions']['groupOnline']['channels'][$i]['channelName']);
	$channel['channel_description'] = $desc;
	$query->channelEdit($config[$instanceid]['functions']['groupOnline']['channels'][$i]['cid'], $channel);
	
	unset($online, $nicks, $clid, $uid,$desc);
	
	}
	}
}

?> 
