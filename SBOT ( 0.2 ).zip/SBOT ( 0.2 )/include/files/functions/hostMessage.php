<?php

class hostMessage
{
	function start()
	{
		global $query;
		global $config;
		global $clients;

		$msg = file_get_contents('include/config/messages/hostMessage.txt', "r");

		$query->serverEdit(array('virtualserver_hostmessage' => self::convert_host_message($msg), 'virtualserver_hostmessage_mode' => 2));
	}
	
	function convert_host_message($msg)
	{
	global $query;
	global $instance;

	$serverinfo = $query->getElement('data', $query->serverInfo());
	
	$result = $instance->convertSeconds($serverinfo['virtualserver_uptime']);
	

	$uptime = '';
	if($result['days']>0)
	{
		$uptime .= ''.$result['days'].' dni ';
	}
	if($result['hours']>0)
	{
		$uptime .= ''.$result['hours'].' godzin ';
	}
	if($result['minutes']>0)
	{
		$uptime .= ''.$result['minutes'].' minut';
	}
	if($uptime=='')
	{
		$uptime .= ''.$result['seconds'].' sekund';
	}

	$podmien = array(
			1 => array(1 => '[connections]', 2 => $serverinfo['virtualserver_client_connections']),
			2 => array(1 => '[server_name]', 2 => $serverinfo['virtualserver_name']),
			3 => array(1 => '[online]', 2 => $serverinfo['virtualserver_clientsonline']),
			4 => array(1 => '[max]', 2 => $serverinfo['virtualserver_maxclients']),
			5 => array(1 => '[uptime]', 2 => $uptime));

	foreach($podmien as $new)
	{
	$msg = str_replace($new[1], $new[2], $msg);
	}
	
	return $msg;
	}
}

?> 
