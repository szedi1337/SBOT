<?php

class multiFunction
{
	function start()
	{
	global $query;
	global $config;
	global $instanceid;
	
	//Informacje na kanałach
	$serverinfo = $query->getElement('data', $query->serverInfo());
	$bots = $serverinfo['virtualserver_queryclientsonline'];
	$users = $serverinfo['virtualserver_clientsonline'];
	$online = $users - $bots;
	$data = array();
	$data['channel_name'] = str_replace('[online]',$online, $config[$instanceid]['functions']['multiFunction']['onlineUsers']['channelName']);
	$query->channelEdit($config[$instanceid]['functions']['multiFunction']['onlineUsers']['cid'], $data);
	$godzina = array();
	$godzina['channel_name'] = str_replace('[hour]', date('H:i'), $config[$instanceid]['functions']['multiFunction']['hour']['channelName']);
	$query->channelEdit($config[$instanceid]['functions']['multiFunction']['hour']['cid'], $godzina);
	$kanaly = array();
	$kanaly['channel_name'] = str_replace('[channels]', $serverinfo['virtualserver_channelsonline'], $config[$instanceid]['functions']['multiFunction']['channels']['channelName']);
	$query->channelEdit($config[$instanceid]['functions']['multiFunction']['channels']['cid'], $kanaly);
	
	$privateChannels = $channel = $query->getElement('data', $query->channelList('-topic -limits'));
	$privateChannelsCount = 0;
	$freeChannelsCount = 0;
	$freeChannelNumbers = array();
	foreach($privateChannels as $channel)
	{
		if($channel['pid']==$config[$instanceid]['functions']['multiFunction']['privateChannels']['pid'] || $channel['pid']==$config[$instanceid]['functions']['multiFunction']['freeChannels']['pid'])
		{
			$privateChannelsCount++;
			
			if($channel['channel_topic']=='wolny')
			{
				$freeChannelsCount++;
				$number = (int)$channel['channel_name'];
				array_push($freeChannelNumbers, $number);
			}
		}
	}
	$prywatne = array();
	$prywatne['channel_name'] = str_replace('[privateChannels]', $privateChannelsCount, $config[$instanceid]['functions']['multiFunction']['privateChannels']['channelName']);
	$query->channelEdit($config[$instanceid]['functions']['multiFunction']['privateChannels']['cid'],$prywatne);
	
	$wolne = array();
	$wolne['channel_name'] = str_replace('[freeChannels]', $freeChannelsCount, $config[$instanceid]['functions']['multiFunction']['freeChannels']['channelName']);
	$desc = '[size=13][b]Lista wolnych kanałów prywatnych:[/b] ';
	for($i=0; $i<count($freeChannelNumbers); $i++)
	{
		$desc .= '' . $freeChannelNumbers[$i] . ', ';
	}
	$desc .= '[/size][hr][right]Wygenerowane przez [b]SBot[/b][/right]';
	$desc .= '';

	$wolne['channel_description'] = $desc;
	$query->channelEdit($config[$instanceid]['functions']['multiFunction']['freeChannels']['cid'],$wolne);
	
	//Rekord Online
	$fp = fopen("cache/onlinerecord", "r");
    $tekst = fread($fp, 100);
	$record_array = explode("/",$tekst);
	fclose($fp);
	if($record_array[0] < $online)
	{
	$fp = fopen("cache/onlinerecord", "w");
	fputs($fp, $online . '/' . time());
	fclose($fp);
	}
	$data = array();
	$data['channel_name'] = str_replace('[record]', $record_array[0], $config[$instanceid]['functions']['multiFunction']['onlineRecord']['channelName']);
	$data['channel_description'] = '[size=13]• Aktualny rekord online wynosi: [b][color=green]'.$record_array[0].'[/b][/color] osób\n• Rekord został ustanowiony: [color=green][b]'.date("d.m.Y", $record_array[1]).'[/b][/color]\n• godzina: [color=green][b]'.date("G:i:s", $record_array[1]).'[/b][/color]/n[hr][right]Wygenerowane przez [b]SBot[/b][/right]';
	$query->channelEdit($config[$instanceid]['functions']['multiFunction']['onlineRecord']['cid'], $data);
	}
}

?> 
