<?php

class nickProtection
{
	function start()
	{
	global $query;
	global $config;
	global $instanceid;
	
	//Sprawdzanie nicków
	$list = $query->getElement('data', $query->clientList());
	foreach((array) $list as $clients)
	{
	for($i = 0; $i<count($config[$instanceid]['functions']['nickProtection']['protectedWords']); $i++)
	{
	if (strpos($clients['client_nickname'], $config[$instanceid]['functions']['nickProtection']['protectedWords'][$i]) !== false) {
	$query->clientKick($clients['clid'], 'server', 'Twoj nick zawiera niezgodne z regulaminem słowo. Zmien nick!');
	}
	}
    }
	}
}

?> 
