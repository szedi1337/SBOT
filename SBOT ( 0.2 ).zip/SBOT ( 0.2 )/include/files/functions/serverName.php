<?php

class serverName
{
	function start()
	{
		global $query;
		global $config;
		global $clients;
		global $instanceid;

		$query->serverEdit(array('virtualserver_name' => self::convertservername($config[$instanceid]['functions']['serverName']['name'])));

	}
		
		function convertservername($msg)
		{
		global $query;

		$serverinfo = $query->getElement('data', $query->serverInfo());

		$online = $serverinfo['virtualserver_clientsonline'] - $serverinfo['virtualserver_queryclientsonline'];

		$podmien = array(
			1 => array(1 => '[online]', 2 => $online),
			2 => array(1 => '[max]', 2 => $serverinfo['virtualserver_maxclients']));

		foreach($podmien as $new)
		{
		$msg = str_replace($new[1], $new[2], $msg);
		}
	
		return $msg;
		}
	
}

?> 
