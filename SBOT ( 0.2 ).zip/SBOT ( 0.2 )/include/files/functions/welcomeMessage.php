<?php

class welcomeMessage
{

	function start()
	{
	global $query;
	global $config;
	global $clients;
	global $instanceid;
	

	
	$msg = fopen('include/config/messages/welcomeMessage.txt', "r");


	$clients['nowi'] = self::clientlist();
if(array_key_exists('actual',$clients))
{
	$clients['roznica'] = array_diff($clients['nowi'], $clients['actual']);



	if(count($clients['roznica']) != 0) {
		foreach($clients['roznica'] as $clid) {
		while(!feof($msg))
		{
		$line = fgets($msg);
		if(!$config[$instanceid]['instance']['enable_database'])
		{
		if(strpos($line, '[topTimeSpent]') || strpos($line, '[topConnectionTime]'))
		{
			$line = null;
		}
		$message = self::convertmsg($line, $clid);
		}
		else
		{
		$message = self::convertDbMsg($line, $clid);
		}
		$query->sendMessage(1, $clid, $message);
		}
		}
		}
}
		
	$clients['actual'] = $clients['nowi'];
	}
	
	function clientlist() {
		
		global $query;
		
		$clients['all'] = $query->getElement('data', $query->clientList());
		
		$clients['recent'] = array();
		foreach($clients['all'] as $client) {
				
				if($client['client_type'] == 0) {
						array_push($clients['recent'], $client['clid']);
				}
		}
		
		return $clients['recent'];
}

function convertmsg($msg, $clientid)
{
global $query;
global $instance;

$client = $query->getElement('data', $query->clientInfo($clientid));
$serverinfo = $query->getElement('data', $query->serverInfo());

	$result = $instance->convertSeconds($serverinfo['virtualserver_uptime']);
	
	$uptime = '';
	if($result['days']>0)
	{
		$uptime .= ''.$result['days'].' dni ';
	}
	if($result['hours']>0)
	{
		$uptime .= ''.$result['hours'].' godzin ';
	}
	if($result['minutes']>0)
	{
		$uptime .= ''.$result['minutes'].' minut';
	}
	if($uptime=='')
	{
		$uptime .= ''.$result['seconds'].' sekund';
	}
	
	$fp = fopen("cache/onlinerecord", "r");
    $tekst = fread($fp, 4);
	$record = (int)$tekst;
	fclose($fp);


$podmien = array(
			1 => array(1 => '[nickname]', 2 => $client['client_nickname']),
			2 => array(1 => '[connections]', 2 => $client['client_totalconnections']),
			3 => array(1 => '[client_first_connected]', 2 => date("d.m.Y", $client['client_created'])),
			4 => array(1 => '[client_last_connected]', 2 => date("d.m.Y", $client['client_lastconnected'])),
			5 => array(1 => '[server_name]', 2 => $serverinfo['virtualserver_name']),
			6 => array(1 => '[online]', 2 => $serverinfo['virtualserver_clientsonline']),
			7 => array(1 => '[max]', 2 => $serverinfo['virtualserver_maxclients']),
			8 => array(1 => '[uptime]', 2 => $uptime),
			9 => array(1 => '[record]', 2 => $record));

	foreach($podmien as $new)
	{
	$msg = str_replace($new[1], $new[2], $msg);
	}
	
	return $msg;
}

function convertDbMsg($msg, $clientid)
{
global $query;
global $instance;
global $instanceid;
global $config;

	if($config[$instanceid]['instance']['enable_database'])
	{
		$mysql_data = $config[$instanceid]['database'];
		$polaczenie = @new mysqli($mysql_data['host'], $mysql_data['user'], $mysql_data['password'], $mysql_data['databaseName']);
		if($polaczenie->connect_error)
		{
			echo '[>>] Błąd łączenia z bazą danych' . PHP_EOL;
			exit();
		}
	}


$client = $query->getElement('data', $query->clientInfo($clientid));
$serverinfo = $query->getElement('data', $query->serverInfo());

	$sql="SELECT * FROM topConnectionTime WHERE uid = '".$client['client_unique_identifier']."' ";

	$result=mysqli_query($polaczenie,$sql);
	$u_data=mysqli_fetch_assoc($result);
	
	if(!$u_data['id']==null && $client['client_type']!=1)
	{
	$init = $u_data['connectionTime']/1000;
	$hours = floor($init / 3600);
	$minutes = floor(($init / 60) % 60);
	$seconds = $init % 60;
	$topConnectionTime = '';
	if($hours>0)
	{
		$topConnectionTime .= ''.$hours.' godzin ';
	}
	if($minutes>0)
	{
		$topConnectionTime .= ''.$minutes.' minut ';
	}
	if($seconds>0)
	{
		$topConnectionTime .= ''.$seconds.' sekund';
	}
	}
	else
	{
		$topConnectionTime = 'Brak najdłuższego czasu połączenia';
	}
	
    $sql="SELECT * FROM topTimeSpent WHERE uid = '".$client['client_unique_identifier']."' ";
	$result=mysqli_query($polaczenie,$sql);
	$u_data=mysqli_fetch_assoc($result);
	
	if($u_data['id']!=null && $client['client_type']!=1)
	{
	$init = $u_data['timeSpent'];
	$hours = floor($init / 3600);
	$minutes = floor(($init / 60) % 60);
	$seconds = $init % 60;
	$topTimeSpent = '';
	if($hours>0)
	{
		$topTimeSpent .= ''.$hours.' godzin ';
	}
	if($minutes>0)
	{
		$topTimeSpent .= ''.$minutes.' minut ';
	}
	if($seconds>0)
	{
		$topTimeSpent .= ''.$seconds.' sekund';
	}
	}
	else
	{
		$topTimeSpent = 'Brak czasu spędzonego na serwerze';
	}
	
	
	
	$result = $instance->convertSeconds($serverinfo['virtualserver_uptime']);
	
	$uptime = '';
	if($result['days']>0)
	{
		$uptime .= ''.$result['days'].' dni ';
	}
	if($result['hours']>0)
	{
		$uptime .= ''.$result['hours'].' godzin ';
	}
	if($result['minutes']>0)
	{
		$uptime .= ''.$result['minutes'].' minut';
	}
	if($uptime=='')
	{
		$uptime .= ''.$result['seconds'].' sekund';
	}
	
	$fp = fopen("cache/onlinerecord", "r");
    $tekst = fread($fp, 4);
	$record = (int)$tekst;
	fclose($fp);


$podmien = array(
			1 => array(1 => '[nickname]', 2 => $client['client_nickname']),
			2 => array(1 => '[connections]', 2 => $client['client_totalconnections']),
			3 => array(1 => '[client_first_connected]', 2 => date("d.m.Y", $client['client_created'])),
			4 => array(1 => '[client_last_connected]', 2 => date("d.m.Y", $client['client_lastconnected'])),
			5 => array(1 => '[server_name]', 2 => $serverinfo['virtualserver_name']),
			6 => array(1 => '[online]', 2 => $serverinfo['virtualserver_clientsonline']),
			7 => array(1 => '[max]', 2 => $serverinfo['virtualserver_maxclients']),
			8 => array(1 => '[uptime]', 2 => $uptime),
			9 => array(1 => '[record]', 2 => $record),
			10 => array(1 => '[topConnectionTime]', 2 => $topConnectionTime),
			11 => array(1 => '[topTimeSpent]', 2 => $topTimeSpent));

	foreach($podmien as $new)
	{
	$msg = str_replace($new[1], $new[2], $msg);
	}
	
	return $msg;
}

}

?> 
