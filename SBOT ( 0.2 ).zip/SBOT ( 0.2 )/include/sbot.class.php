<?php ?><?php
include_once 'classes/ts3admin.class.php';
include_once 'include/config/config.php';
include_once 'cache/functions_time.php';
class sbot {
    function __construct() {
    }
    function convertinterval($interval) {
        $interval['hours'] = $interval['hours'] + $interval['days'] * 24;
        $interval['minutes'] = $interval['minutes'] + $interval['hours'] * 60;
        $interval['seconds'] = $interval['seconds'] + $interval['minutes'] * 60;
        return $interval['seconds'];
    }
    function can_do($function, $date2, $interval) {
        $time2 = strtotime($date2);
        $time1 = strtotime(date('Y-m-d G:i:s'));
        $sum = $time1 - $time2;
        if ($sum >= $interval) {
            $cando = true;
        } else {
            $cando = false;
        }
        return $cando;
    }
    function sendCommand($command) {
        global $tsAdminSocket;
        $splittedCommand = str_split($command, 1024);
        $splittedCommand[(count($splittedCommand) - 1) ].= "
";
        foreach ($splittedCommand as $commandPart) {
            fputs($tsAdminSocket, $commandPart);
        }
        return fgets($tsAdminSocket, 4096);
    }
    function getData() {
        global $tsAdminSocket;
        $data = fgets($tsAdminSocket, 4096);
        if (!empty($data)) {
            $datasets = explode(' ', $data);
            $output = array();
            foreach ($datasets as $dataset) {
                $dataset = explode('=', $dataset);
                if (count($dataset) > 2) {
                    for ($i = 2;$i < count($dataset);$i++) {
                        $dataset[1].= '=' . $dataset[$i];
                    }
                    $output[self::unEscapeText($dataset[0]) ] = self::unEscapeText($dataset[1]);
                } else {
                    if (count($dataset) == 1) {
                        $output[self::unEscapeText($dataset[0]) ] = '';
                    } else {
                        $output[self::unEscapeText($dataset[0]) ] = self::unEscapeText($dataset[1]);
                    }
                }
            }
            return $output;
        }
    }
    function unEscapeText($text) {
        $escapedChars = array("	", "", "
", "
", "", "\s", "\p", "\/");
        $unEscapedChars = array('', '', '', '', '', ' ', '|', '/');
        $text = str_replace($escapedChars, $unEscapedChars, $text);
        return $text;
    }
    function isInGroup($usergroups, $group) {
        $diff = count(array_diff($usergroups, $group));
        if ($diff < count($usergroups)) {
            return true;
        } else {
            return false;
        }
    }
    function convertSeconds($seconds) {
        $result['days'] = floor($seconds / 86400);
        $result['hours'] = floor(($seconds - ($result['days'] * 86400)) / 3600);
        $result['minutes'] = floor(($seconds - ($result['days'] * 86400) - ($result['hours'] * 3600)) / 60);
        $result['seconds'] = floor(($seconds - ($result['days'] * 86400) - ($result['hours'] * 3600) - ($result['minutes'] * 60)));
        return $result;
    }
     function checkLicense() {
        return true;
    }
}
?>